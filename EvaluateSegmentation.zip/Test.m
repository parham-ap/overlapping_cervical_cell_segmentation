% This is an example of how EvaluateSegmentation function can be called.
% The included ground truth and segmentation result mat files contain masks
% for the ground truth and the segmented region(s) in a hypothetical
% dataset containing a single synthetic image.

load('GroundTruth.mat');
load ('SegmentationResult.mat');

[DSC, FNRo, TPRp, FDRo, stdDSC, stdFNRo, stdTPRp, stdFDRo] = ...
    EvaluateSegmentation(groundTruth, segmentationResult);

fprintf('DSC  � std\tFNRo � std\tTPRp � std\tFDRo � std\n')
fprintf('%.3f�%.3f\t%.3f�%.3f\t%.3f�%.3f\t%.3f�%.3f\n', ...
    DSC, stdDSC, FNRo, stdFNRo, TPRp, stdTPRp, FDRo, stdFDRo);
